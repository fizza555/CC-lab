namespace lab1task2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.Columns.Add("StudentNameColumn", "Student Name");
            dataGridView1.Columns.Add("SemesterColumn", "Semester");
            dataGridView1.Columns.Add("CGPAColumn", "CGPA");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string studentName = textBox1.Text;
            string semester = textBox2.Text;
            string cgpa = textBox3.Text;

            // Validate input (You can add more validation as needed)
            if (string.IsNullOrWhiteSpace(studentName) || string.IsNullOrWhiteSpace(semester) || string.IsNullOrWhiteSpace(cgpa))
            {
                MessageBox.Show("Please enter all fields.");
                return;
            }

            // Insert values into DataGridView
            dataGridView1.Rows.Add(studentName, semester, cgpa);

            // Clear textboxes after insertion
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }
    }
}
    
