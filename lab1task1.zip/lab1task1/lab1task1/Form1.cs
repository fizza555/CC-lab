using System;
using System.Windows.Forms;

namespace lab1task1
{
    public partial class Form1 : Form
    {
        private double currentNumber = 0;
        private double result = 0;
        private char operation = ' ';

        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate()
        {
            double inputNumber;
            if (operation != 's' && operation != 'c' && operation != 't' && operation != 'l')
            {
                // For basic operations, parse the entire textbox content
                if (!double.TryParse(textBox1.Text, out inputNumber))
                {
                    MessageBox.Show("Invalid input! Please enter a valid number.");
                    return;
                }
            }
            else
            {
                // For trigonometric and logarithmic functions, parse only the number part after the function text
                string numberText = textBox1.Text.Substring(3); // Skip the first three characters (e.g., "sin")
                if (!double.TryParse(numberText, out inputNumber))
                {
                    MessageBox.Show("Invalid input! Please enter a valid number after the function.");
                    return;
                }
            }

            switch (operation)
            {
                case '+':
                    result = currentNumber + inputNumber;
                    break;
                case '-':
                    result = currentNumber - inputNumber;
                    break;
                case '*':
                    result = currentNumber * inputNumber;
                    break;
                case '/':
                    if (inputNumber != 0)
                        result = currentNumber / inputNumber;
                    else
                        MessageBox.Show("Cannot divide by zero!");
                    break;
                case 's':
                    result = Math.Sin(inputNumber);
                    break;
                case 'c':
                    result = Math.Cos(inputNumber);
                    break;
                case 't':
                    result = Math.Tan(inputNumber);
                    break;
                case 'l':
                    if (inputNumber > 0)
                        result = Math.Log(inputNumber);
                    else
                        MessageBox.Show("Logarithm is undefined for non-positive numbers!");
                    break;
            }
            textBox1.Text = result.ToString();
        }


        private void one_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void two_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void three_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void four_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void five_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void six_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string digit = button.Text;
            textBox1.Text += digit;
        }

        private void equal_Click(object sender, EventArgs e)
        {
            Calculate(); // Calculate the result
            operation = ' '; // Reset the operation
            currentNumber = 0; // Reset the current number
        }

        private void clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            currentNumber = 0;
            result = 0;
            operation = ' ';
        }

        private void divide_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            char newOperation = button.Text[0];
            operation = newOperation;
            currentNumber = double.Parse(textBox1.Text);
            textBox1.Text = "";
        }

        private void mutiply_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            char newOperation = button.Text[0];
            operation = newOperation;
            currentNumber = double.Parse(textBox1.Text);
            textBox1.Text = "";
        }

        private void add_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            char newOperation = button.Text[0];
            operation = newOperation;
            currentNumber = double.Parse(textBox1.Text);
            textBox1.Text = "";
        }

        private void subtraction_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            char newOperation = button.Text[0];
            operation = newOperation;
            currentNumber = double.Parse(textBox1.Text);
            textBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            operation = 's';
            textBox1.Text = "sin";
        }

        private void Cos_Click(object sender, EventArgs e)
        {
            
            operation = 'c';
            textBox1.Text = "cos";
        }

        private void tan_Click(object sender, EventArgs e)
        {
           
            operation = 't';
            textBox1.Text = "tan";
        }

        private void log_Click(object sender, EventArgs e)
        {
           
            operation = 'l';
            textBox1.Text = "log";
        }
    }
}
