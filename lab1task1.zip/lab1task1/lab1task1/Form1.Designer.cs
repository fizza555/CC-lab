﻿namespace lab1task1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            one = new Button();
            two = new Button();
            three = new Button();
            four = new Button();
            five = new Button();
            six = new Button();
            seven = new Button();
            eight = new Button();
            nine = new Button();
            divide = new Button();
            mutiply = new Button();
            add = new Button();
            subtraction = new Button();
            clear = new Button();
            dot = new Button();
            equal = new Button();
            Sine = new Button();
            log = new Button();
            Cos = new Button();
            tan = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 25);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(363, 46);
            textBox1.TabIndex = 0;
            // 
            // one
            // 
            one.Location = new Point(12, 99);
            one.Name = "one";
            one.Size = new Size(112, 34);
            one.TabIndex = 1;
            one.Text = "1";
            one.UseVisualStyleBackColor = true;
            one.Click += one_Click;
            // 
            // two
            // 
            two.Location = new Point(135, 99);
            two.Name = "two";
            two.Size = new Size(112, 34);
            two.TabIndex = 2;
            two.Text = "2";
            two.UseVisualStyleBackColor = true;
            two.Click += two_Click;
            // 
            // three
            // 
            three.Location = new Point(253, 99);
            three.Name = "three";
            three.Size = new Size(112, 34);
            three.TabIndex = 3;
            three.Text = "3";
            three.UseVisualStyleBackColor = true;
            three.Click += three_Click;
            // 
            // four
            // 
            four.Location = new Point(12, 164);
            four.Name = "four";
            four.Size = new Size(112, 34);
            four.TabIndex = 4;
            four.Text = "4";
            four.UseVisualStyleBackColor = true;
            four.Click += four_Click;
            // 
            // five
            // 
            five.Location = new Point(135, 168);
            five.Name = "five";
            five.Size = new Size(112, 34);
            five.TabIndex = 5;
            five.Text = "5";
            five.UseVisualStyleBackColor = true;
            five.Click += five_Click;
            // 
            // six
            // 
            six.Location = new Point(253, 168);
            six.Name = "six";
            six.Size = new Size(112, 34);
            six.TabIndex = 6;
            six.Text = "6";
            six.UseVisualStyleBackColor = true;
            six.Click += six_Click;
            // 
            // seven
            // 
            seven.Location = new Point(12, 226);
            seven.Name = "seven";
            seven.Size = new Size(112, 34);
            seven.TabIndex = 7;
            seven.Text = "7";
            seven.UseVisualStyleBackColor = true;
            seven.Click += seven_Click;
            // 
            // eight
            // 
            eight.Location = new Point(135, 226);
            eight.Name = "eight";
            eight.Size = new Size(112, 34);
            eight.TabIndex = 8;
            eight.Text = "8";
            eight.UseVisualStyleBackColor = true;
            eight.Click += eight_Click;
            // 
            // nine
            // 
            nine.Location = new Point(253, 226);
            nine.Name = "nine";
            nine.Size = new Size(112, 34);
            nine.TabIndex = 9;
            nine.Text = "0";
            nine.UseVisualStyleBackColor = true;
            nine.Click += nine_Click;
            // 
            // divide
            // 
            divide.Location = new Point(410, 99);
            divide.Name = "divide";
            divide.Size = new Size(97, 34);
            divide.TabIndex = 10;
            divide.Text = "/";
            divide.UseVisualStyleBackColor = true;
            divide.Click += divide_Click;
            // 
            // mutiply
            // 
            mutiply.Location = new Point(410, 152);
            mutiply.Name = "mutiply";
            mutiply.Size = new Size(97, 34);
            mutiply.TabIndex = 11;
            mutiply.Text = "*";
            mutiply.UseVisualStyleBackColor = true;
            mutiply.Click += mutiply_Click;
            // 
            // add
            // 
            add.Location = new Point(410, 201);
            add.Name = "add";
            add.Size = new Size(97, 34);
            add.TabIndex = 12;
            add.Text = "+";
            add.UseVisualStyleBackColor = true;
            add.Click += add_Click;
            // 
            // subtraction
            // 
            subtraction.Location = new Point(410, 250);
            subtraction.Name = "subtraction";
            subtraction.Size = new Size(97, 34);
            subtraction.TabIndex = 13;
            subtraction.Text = "-";
            subtraction.UseVisualStyleBackColor = true;
            subtraction.Click += subtraction_Click;
            // 
            // clear
            // 
            clear.Location = new Point(17, 279);
            clear.Name = "clear";
            clear.Size = new Size(112, 34);
            clear.TabIndex = 14;
            clear.Text = "C";
            clear.UseVisualStyleBackColor = true;
            clear.Click += clear_Click;
            // 
            // dot
            // 
            dot.Location = new Point(135, 279);
            dot.Name = "dot";
            dot.Size = new Size(112, 34);
            dot.TabIndex = 15;
            dot.Text = ".";
            dot.UseVisualStyleBackColor = true;
            // 
            // equal
            // 
            equal.Location = new Point(263, 279);
            equal.Name = "equal";
            equal.Size = new Size(112, 34);
            equal.TabIndex = 16;
            equal.Text = "=";
            equal.UseVisualStyleBackColor = true;
            equal.Click += equal_Click;
            // 
            // Sine
            // 
            Sine.Location = new Point(12, 334);
            Sine.Name = "Sine";
            Sine.Size = new Size(112, 34);
            Sine.TabIndex = 17;
            Sine.Text = "sin";
            Sine.UseVisualStyleBackColor = true;
            Sine.Click += button1_Click;
            // 
            // log
            // 
            log.Location = new Point(147, 374);
            log.Name = "log";
            log.Size = new Size(112, 34);
            log.TabIndex = 18;
            log.Text = "log";
            log.UseVisualStyleBackColor = true;
            log.Click += log_Click;
            // 
            // Cos
            // 
            Cos.Location = new Point(147, 334);
            Cos.Name = "Cos";
            Cos.Size = new Size(112, 34);
            Cos.TabIndex = 19;
            Cos.Text = "cos";
            Cos.UseVisualStyleBackColor = true;
            Cos.Click += Cos_Click;
            // 
            // tan
            // 
            tan.Location = new Point(12, 383);
            tan.Name = "tan";
            tan.Size = new Size(112, 34);
            tan.TabIndex = 20;
            tan.Text = "tan";
            tan.UseVisualStyleBackColor = true;
            tan.Click += tan_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(509, 450);
            Controls.Add(tan);
            Controls.Add(Cos);
            Controls.Add(log);
            Controls.Add(Sine);
            Controls.Add(equal);
            Controls.Add(dot);
            Controls.Add(clear);
            Controls.Add(subtraction);
            Controls.Add(add);
            Controls.Add(mutiply);
            Controls.Add(divide);
            Controls.Add(nine);
            Controls.Add(eight);
            Controls.Add(seven);
            Controls.Add(six);
            Controls.Add(five);
            Controls.Add(four);
            Controls.Add(three);
            Controls.Add(two);
            Controls.Add(one);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button one;
        private Button two;
        private Button three;
        private Button four;
        private Button five;
        private Button six;
        private Button seven;
        private Button eight;
        private Button nine;
        private Button divide;
        private Button mutiply;
        private Button add;
        private Button subtraction;
        private Button clear;
        private Button dot;
        private Button equal;
        private Button Sine;
        private Button log;
        private Button Cos;
        private Button tan;
    }
}
