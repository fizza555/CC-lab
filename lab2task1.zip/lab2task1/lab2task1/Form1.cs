using System.Text.RegularExpressions;

namespace lab2task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      

        private void display_Click(object sender, EventArgs e)
        {
            string operatorInput = textBox1.Text.Trim();
            string regex = GenerateRegexForOperator(operatorInput);
            textBox2.Text = regex;
        }

        private string GenerateRegexForOperator(string operatorInput)
        {
            switch (operatorInput.ToLower())
            {
                case "and":
                    return "&&";
                case "or":
                    return @"\|\|";
                case "not":
                    return "!";
                default:
                    return "Unknown operator";
            }
        }
    }
}


